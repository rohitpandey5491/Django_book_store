from django.conf.urls import url
from . import views
urlpatterns = [
    #url(r'^$', views.get_auther_name, name='get_auther_name'),
    url(r'mybook/views/$', views.get_auther_name, name='get_auther_name'),

]