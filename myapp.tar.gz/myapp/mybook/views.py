from django.shortcuts import render
from mybook import models
from django.http import JsonResponse

def get_auther_name(request):
    result =[]
    res= models.Book.objects.values()
    for i in res:
        json = {}
        for k, v in i.items():
            json[k]= v
        result.append(json)
    return  JsonResponse(dict(key=result))