from __future__ import unicode_literals
from django.db import models
from django.utils import timezone

class get_auther_name(models.Model):
    name = models.CharField(max_length=100)

class get_book_name(models.Model):
    name = models.CharField(max_length=300)

class Book(models.Model):
    auther_name = models.CharField(max_length=140, default='DEFAULT VALUE', blank=True, null=True)
    #author_name = models.ManyToManyField(get_auther_name)
    book_title = models.CharField(max_length=140, default='DEFAULT VALUE', blank=True, null=True)
    #book_title  = models.ForeignKey(get_book_name)
    pages = models.IntegerField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    rating = models.FloatField()
    pubdate = models.DateField()

    def publish(self):
        self.pubdate = timezone.now()
        self.save()

    #def __str__(self):
        #return self.book_title


